// Arquivo: src/data/systemData.js

export const SYSTEM_DATA = {
    Sbase: 1000, 
    Vbase: 13.8, 
    Vmax: 1.00, 
    Vmin: 0.95,
    sources: [101, 102, 104], 
    sses: { 101: 33400, 102: 30000, 104: 22000 },    
    shunts: {},  
    dgs: {},     
    oltcs: {},   
    positionsProject: {
        '1': { x: 240, y: 75 }, '2': { x: 150, y: 145 }, '3': { x: 690, y: 75 }, '4': { x: 690, y: 150 },
        '5': { x: 780, y: 150 }, '6': { x: 780, y: 300 }, '7': { x: 510, y: 150 }, '8': { x: 510, y: 225 },
        '9': { x: 240, y: 225 }, '10': { x: 240, y: 300 }, '11': { x: 330, y: 600 }, '12': { x: 60, y: 600 },
        '13': { x: 60, y: 450 }, '14': { x: 510, y: 600 }, '15': { x: 510, y: 525 }, '16': { x: 420, y: 525 },
        '17': { x: 150, y: 225 }, '18': { x: 60, y: 225 }, '19': { x: 60, y: 145 }, '20': { x: 150, y: 75 },
        '21': { x: 60, y: 300 }, '22': { x: 330, y: 225 }, '23': { x: 330, y: 150 }, '24': { x: 420, y: 150 },
        '25': { x: 420, y: 225 }, '26': { x: 600, y: 188 }, '27': { x: 690, y: 225 }, '28': { x: 690, y: 300 },
        '29': { x: 60, y: 370 }, '30': { x: 150, y: 370 }, '31': { x: 240, y: 370 }, '32': { x: 420, y: 375 },
        '33': { x: 510, y: 300 }, '34': { x: 600, y: 300 }, '35': { x: 510, y: 375 }, '36': { x: 600, y: 375 },
        '37': { x: 240, y: 450 }, '38': { x: 330, y: 300 }, '39': { x: 420, y: 300 }, '40': { x: 420, y: 450 },
        '41': { x: 510, y: 450 }, '42': { x: 690, y: 450 }, '43': { x: 150, y: 450 }, '44': { x: 330, y: 525 },
        '45': { x: 240, y: 525 }, '46': { x: 690, y: 600 }, '47': { x: 690, y: 525 }, '48': { x: 780, y: 450 },
        '49': { x: 780, y: 375 }, '50': { x: 690, y: 375 },
        '101': { x: 420, y: 75 }, '102': { x: 420, y: 600 }, '104': { x: 150, y: 300 }
    },
    positionsOrganic: {},
    waypointsProject: {},
    loads: {
        '1': {p:2910.6,q:1409.6}, '2': {p:1039.5,q:503.4}, '3': {p:485.1,q:234.9}, '4': {p:762.3,q:369.2},
        '5': {p:1801.8,q:872.6}, '6': {p:485.1,q:234.9}, '7': {p:693.0,q:335.6}, '8': {p:1316.7,q:637.7},
        '9': {p:831.6,q:402.8}, '10': {p:2009.7,q:973.4}, '11': {p:207.9,q:100.7}, '12': {p:1247.4,q:604.1},
        '13': {p:762.3,q:369.2}, '14': {p:693.0,q:335.6}, '15': {p:970.2,q:469.9}, '16': {p:1316.7,q:637.7},
        '17': {p:485.1,q:234.9}, '18': {p:831.6,q:402.8}, '19': {p:970.2,q:469.9}, '20': {p:554.4,q:268.5},
        '21': {p:1247.4,q:604.1}, '22': {p:762.3,q:369.2}, '23': {p:693.0,q:335.6}, '24': {p:346.5,q:167.8},
        '25': {p:623.7,q:302.1}, '26': {p:831.6,q:402.8}, '27': {p:1039.5,q:503.4}, '28': {p:485.1,q:234.9},
        '29': {p:970.2,q:469.9}, '30': {p:1801.8,q:872.6}, '31': {p:485.1,q:234.9}, '32': {p:1178.1,q:570.6},
        '33': {p:2009.7,q:973.4}, '34': {p:831.6,q:402.8}, '35': {p:623.7,q:302.1}, '36': {p:207.9,q:100.7},
        '37': {p:1455.3,q:704.9}, '38': {p:762.3,q:369.2}, '39': {p:693.0,q:335.6}, '40': {p:970.2,q:469.9},
        '41': {p:623.7,q:302.1}, '42': {p:831.6,q:402.8}, '43': {p:900.9,q:436.4}, '44': {p:970.2,q:469.9},
        '45': {p:554.4,q:268.5}, '46': {p:1247.4,q:604.1}, '47': {p:693.0,q:335.6}, '48': {p:554.4,q:268.5},
        '49': {p:346.5,q:167.8}, '50': {p:554.4,q:268.5}
    },
    branches: [
        {from:101, to:1, hasSwitch:true, r:0.054289, x:0.067496, Imax:600, initialState:1}, {from:101, to:3, hasSwitch:true, r:0.042118, x:0.052364, Imax:600, initialState:1},
        {from:4, to:3, hasSwitch:true, r:0.060278, x:0.074942, Imax:600, initialState:1}, {from:7, to:4, hasSwitch:true, r:0.048300, x:0.060050, Imax:600, initialState:1},
        {from:5, to:4, hasSwitch:true, r:0.147202, x:0.149885, Imax:250, initialState:1}, {from:8, to:7, hasSwitch:true, r:0.060278, x:0.074942, Imax:600, initialState:1},
        {from:6, to:5, hasSwitch:true, r:0.117950, x:0.120100, Imax:250, initialState:1}, {from:9, to:1, hasSwitch:true, r:0.066268, x:0.082389, Imax:600, initialState:1},
        {from:104, to:30, hasSwitch:true, r:0.054289, x:0.067496, Imax:600, initialState:1}, {from:29, to:30, hasSwitch:true, r:0.228072, x:0.157248, Imax:150, initialState:1},
        {from:43, to:30, hasSwitch:true, r:0.191551, x:0.195042, Imax:250, initialState:1}, {from:37, to:43, hasSwitch:true, r:0.182750, x:0.126000, Imax:150, initialState:1},
        {from:31, to:37, hasSwitch:true, r:0.136697, x:0.094248, Imax:150, initialState:1}, {from:43, to:13, hasSwitch:true, r:0.109500, x:0.092475, Imax:400, initialState:1},
        {from:45, to:12, hasSwitch:true, r:0.048300, x:0.060050, Imax:600, initialState:1}, {from:2, to:1, hasSwitch:true, r:0.147202, x:0.149885, Imax:250, initialState:1},
        {from:10, to:9, hasSwitch:true, r:0.338752, x:0.344927, Imax:250, initialState:1}, {from:102, to:14, hasSwitch:true, r:0.072450, x:0.090075, Imax:600, initialState:1},
        {from:15, to:14, hasSwitch:true, r:0.176925, x:0.180150, Imax:250, initialState:1}, {from:16, to:15, hasSwitch:true, r:0.132576, x:0.134992, Imax:250, initialState:1},
        {from:102, to:11, hasSwitch:true, r:0.054289, x:0.067496, Imax:600, initialState:1}, {from:12, to:11, hasSwitch:true, r:0.060278, x:0.074942, Imax:600, initialState:1},
        {from:20, to:19, hasSwitch:true, r:0.228072, x:0.157248, Imax:150, initialState:1}, {from:19, to:18, hasSwitch:true, r:0.182750, x:0.126000, Imax:150, initialState:1},
        {from:17, to:9, hasSwitch:true, r:0.125560, x:0.106038, Imax:400, initialState:1}, {from:21, to:18, hasSwitch:true, r:0.147202, x:0.149885, Imax:250, initialState:1},
        {from:104, to:21, hasSwitch:true, r:0.073000, x:0.061650, Imax:400, initialState:1}, {from:22, to:9, hasSwitch:true, r:0.220802, x:0.224827, Imax:250, initialState:1},
        {from:23, to:22, hasSwitch:true, r:0.250733, x:0.172872, Imax:150, initialState:1}, {from:24, to:23, hasSwitch:true, r:0.205411, x:0.141624, Imax:150, initialState:1},
        {from:25, to:24, hasSwitch:true, r:0.159358, x:0.109872, Imax:150, initialState:1}, {from:27, to:8, hasSwitch:true, r:0.176925, x:0.180150, Imax:250, initialState:1},
        {from:26, to:27, hasSwitch:true, r:0.250733, x:0.172872, Imax:150, initialState:1}, {from:28, to:6, hasSwitch:true, r:0.365500, x:0.252000, Imax:150, initialState:1},
        {from:44, to:45, hasSwitch:true, r:0.042118, x:0.052364, Imax:600, initialState:1}, {from:38, to:44, hasSwitch:true, r:0.060278, x:0.074942, Imax:600, initialState:1},
        {from:39, to:38, hasSwitch:true, r:0.080948, x:0.082389, Imax:500, initialState:1}, {from:32, to:39, hasSwitch:true, r:0.296786, x:0.204624, Imax:150, initialState:1},
        {from:33, to:39, hasSwitch:true, r:0.132576, x:0.134992, Imax:250, initialState:1}, {from:34, to:33, hasSwitch:true, r:0.136697, x:0.094248, Imax:150, initialState:1},
        {from:35, to:34, hasSwitch:true, r:0.159358, x:0.109872, Imax:150, initialState:1}, {from:36, to:35, hasSwitch:true, r:0.159358, x:0.109872, Imax:150, initialState:1},
        {from:16, to:40, hasSwitch:true, r:0.182750, x:0.126000, Imax:150, initialState:1}, {from:42, to:41, hasSwitch:true, r:0.274125, x:0.189000, Imax:150, initialState:1},
        {from:48, to:42, hasSwitch:true, r:0.182750, x:0.126000, Imax:150, initialState:1}, {from:49, to:48, hasSwitch:true, r:0.274125, x:0.189000, Imax:150, initialState:1},
        {from:50, to:49, hasSwitch:true, r:0.159358, x:0.109872, Imax:150, initialState:1}, {from:47, to:42, hasSwitch:true, r:0.091104, x:0.076939, Imax:400, initialState:1},
        {from:46, to:47, hasSwitch:true, r:0.147202, x:0.149885, Imax:250, initialState:1}, {from:14, to:46, hasSwitch:true, r:0.100156, x:0.084584, Imax:400, initialState:1},
        
        {from:10, to:31, hasSwitch:true, r:0.228072, x:0.157248, Imax:150, initialState:0}, {from:13, to:12, hasSwitch:true, r:0.319447, x:0.220248, Imax:150, initialState:0},
        {from:18, to:17, hasSwitch:true, r:0.296786, x:0.204624, Imax:150, initialState:0}, {from:104, to:22, hasSwitch:true, r:0.176925, x:0.180150, Imax:250, initialState:0},
        {from:8, to:25, hasSwitch:true, r:0.205411, x:0.141624, Imax:150, initialState:0}, {from:28, to:27, hasSwitch:true, r:0.228072, x:0.157248, Imax:150, initialState:0},
        {from:8, to:33, hasSwitch:true, r:0.220802, x:0.224827, Imax:250, initialState:0}, {from:40, to:41, hasSwitch:true, r:0.274125, x:0.189000, Imax:150, initialState:0},
        {from:35, to:40, hasSwitch:true, r:0.130118, x:0.089712, Imax:150, initialState:0}, {from:10, to:38, hasSwitch:true, r:0.182750, x:0.126000, Imax:150, initialState:0},
        {from:28, to:50, hasSwitch:true, r:0.112574, x:0.077616, Imax:150, initialState:0},
    ]
};

// Coordenadas fictícias em Ilha Solteira para o nosso teste geográfico
export const GEO_POSITIONS = {
    '1000': { lat: -20.4319, lng: -51.3425 }, // Centro de Ilha Solteira
    '101':  { lat: -20.4350, lng: -51.3400 }, // Um pouco para o Sul
    '102':  { lat: -20.4280, lng: -51.3450 }, // Um pouco para o Norte
    '1':    { lat: -20.4365, lng: -51.3380 }, // Barra de carga
    '2':    { lat: -20.4380, lng: -51.3350 }, // Barra de carga
};