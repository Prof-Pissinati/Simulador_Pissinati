import React, { useState } from 'react';
import { MapContainer, TileLayer, Tooltip, Polyline, Marker } from 'react-leaflet';
import L from 'leaflet';
import { GEO_POSITIONS as INITIAL_GEO } from '../data/systemDataGeo';
import { fetchStreetRoute } from '../utils/geoRouting';

export default function MapArea({ 
    darkMode, branches, sources, feedersList, getNodeColor, 
    getEdgeColor, setSelectedElement, toggleSwitch, toggleFault,
    nodeData, lineCurrents, systemShunts, children, isEditMode // 👈 Adicionado systemShunts
}) {
    const center = [-20.4319, -51.3425];
    const mapTileUrl = darkMode 
        ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png' 
        : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';

    const [geoPositions, setGeoPositions] = useState(INITIAL_GEO);
    const [routedPaths, setRoutedPaths] = useState({});
    const [isRouting, setIsRouting] = useState(false);
    const [routeProgress, setRouteProgress] = useState(0);
    
    // 👇 NOVO: Estado para mostrar qual linha está sendo recalculada
    const [recalculatingBranchId, setRecalculatingBranchId] = useState(null);

    // FUNÇÃO: Recalcular rota individual
    const recalculateSingleRoute = async (branchId) => {
        const branch = branches.find(b => b.id === branchId);
        if (!branch) return;

        setRecalculatingBranchId(branchId); // Mostra o aviso

        const p1 = geoPositions[branch.from];
        const p2 = geoPositions[branch.to];
        
        if (p1 && p2) {
            const route = await fetchStreetRoute(p1.lat, p1.lng, p2.lat, p2.lng);
            if (route) {
                setRoutedPaths(prev => ({ 
                    ...prev, 
                    [branchId]: [[p1.lat, p1.lng], ...route, [p2.lat, p2.lng]] 
                }));
            }
        }
        setRecalculatingBranchId(null); // Esconde o aviso
    };

    const handleCalculateRealRoutes = async () => {
        setIsRouting(true);
        setRouteProgress(0);
        const newRoutes = { ...routedPaths };

        for (let i = 0; i < branches.length; i++) {
            const branch = branches[i];
            if (newRoutes[branch.id]) continue; 

            const p1 = geoPositions[branch.from];
            const p2 = geoPositions[branch.to];
            
            if (p1 && p2) {
                const route = await fetchStreetRoute(p1.lat, p1.lng, p2.lat, p2.lng);
                if (route) {
                    newRoutes[branch.id] = [[p1.lat, p1.lng], ...route, [p2.lat, p2.lng]];
                    setRoutedPaths({ ...newRoutes }); 
                }
            }
            setRouteProgress(Math.round(((i + 1) / branches.length) * 100));
            // 👇 Aumentamos para 600ms para o OSRM não te bloquear por excesso de velocidade!
            await new Promise(r => setTimeout(r, 600)); 
        }
        setIsRouting(false);
    };

    const handleExportRoutes = () => {
        if (Object.keys(routedPaths).length === 0) {
            alert("Trace as rotas primeiro antes de exportar!");
            return;
        }
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(routedPaths, null, 2));
        const downloadAnchorNode = document.createElement('a');
        downloadAnchorNode.setAttribute("href", dataStr);
        downloadAnchorNode.setAttribute("download", "systemRoutes.json");
        document.body.appendChild(downloadAnchorNode);
        downloadAnchorNode.click();
        downloadAnchorNode.remove();
    };

    // 👇 MÁGICA VISUAL: Recria as mesmas formas SVG do seu projeto original
    const createCustomIcon = (nodeId, color, type) => {
        let shape = '';
        const strokeColor = darkMode ? '#121212' : '#ffffff';
        const hasShunt = systemShunts && systemShunts[nodeId];

        if (type === 'sub') {
            // Círculo Grande (Ex: 1000)
            shape = `<circle cx="10" cy="10" r="8" fill="${color}" stroke="${strokeColor}" stroke-width="1.5"/>`;
        } else if (type === 'feeder') {
            // Hexágono (Ex: 101, 102)
            shape = `<polygon points="10,1 18,5 18,15 10,19 2,15 2,5" fill="${color}" stroke="${strokeColor}" stroke-width="1.5"/>`;
        } else if (hasShunt) {
            // Losango para capacitores (Ex: 16, 24)
            shape = `<polygon points="10,2 18,10 10,18 2,10" fill="${color}" stroke="${strokeColor}" stroke-width="1.5"/>`;
        } else {
            // Quadrado para barras comuns
            shape = `<rect x="4" y="4" width="12" height="12" rx="2" fill="${color}" stroke="${strokeColor}" stroke-width="1.5"/>`;
        }

        return L.divIcon({
            className: 'custom-node',
            html: `<svg width="20" height="20" viewBox="0 0 20 20">${shape}</svg>`,
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        });
    };

    const handleNodeDrag = (nodeId, newLatLng) => {
        setGeoPositions(prev => ({
            ...prev,
            [nodeId]: { lat: newLatLng.lat, lng: newLatLng.lng }
        }));
    };

    return (
        <div style={{ width: '100%', height: '100%', position: 'relative', zIndex: 1 }}>
            
            {/* PAINEL DE CONTROLE */}
            <div style={{ position: 'absolute', top: '20px', left: '50%', transform: 'translateX(-50%)', zIndex: 1000, background: darkMode ? 'rgba(30, 30, 30, 0.9)' : 'rgba(255, 255, 255, 0.9)', padding: '10px 20px', borderRadius: '12px', boxShadow: '0 4px 15px rgba(0,0,0,0.3)', backdropFilter: 'blur(10px)', border: `1px solid ${darkMode ? '#444' : '#ddd'}`, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
                <div style={{ display: 'flex', gap: '10px' }}>
                    <button onClick={handleCalculateRealRoutes} disabled={isRouting} style={{ background: isRouting ? '#555' : '#00bcd4', color: '#fff', border: 'none', padding: '8px 16px', borderRadius: '6px', fontWeight: 'bold', cursor: isRouting ? 'wait' : 'pointer', transition: 'background 0.3s' }}>
                        {isRouting ? `🛰️ Mapeando Ruas (${routeProgress}%)...` : '🛣️ Traçar Rotas (OSRM)'}
                    </button>
                    <button onClick={handleExportRoutes} style={{ background: '#ff9800', color: '#fff', border: 'none', padding: '8px 16px', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer' }}>
                        💾 Exportar Rotas
                    </button>
                    
                    {isEditMode && (
                        <button onClick={() => { console.log(JSON.stringify(geoPositions, null, 4)); alert("As coordenadas finais foram enviadas para o Console! Pressione F12 para copiar."); }} style={{ background: '#4caf50', color: '#fff', border: 'none', padding: '8px 16px', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer' }}>
                            💾 Exportar Posições
                        </button>
                    )}
                </div>
                {isRouting && (
                    <div style={{ width: '100%', height: '4px', background: '#333', borderRadius: '2px', overflow: 'hidden' }}>
                        <div style={{ width: `${routeProgress}%`, height: '100%', background: '#00bcd4', transition: 'width 0.3s' }}></div>
                    </div>
                )}
            </div>

            {/* 👇 AVISO DE RECÁLCULO INDIVIDUAL 👇 */}
            {recalculatingBranchId !== null && (
                <div style={{ position: 'absolute', top: '80px', left: '50%', transform: 'translateX(-50%)', zIndex: 1000, background: '#e91e63', color: 'white', padding: '8px 16px', borderRadius: '20px', fontWeight: 'bold', fontSize: '13px', boxShadow: '0 4px 10px rgba(233,30,99,0.4)', animation: 'pulse 1.5s infinite' }}>
                    🛰️ Recalculando rota da linha...
                </div>
            )}

            <MapContainer center={center} zoom={15} style={{ width: '100%', height: '100%', background: darkMode ? '#121212' : '#f0f2f5' }}>
                <TileLayer url={mapTileUrl} attribution='&copy; OpenStreetMap' />

                {branches.map(branch => {
                    const p1 = geoPositions[branch.from];
                    const p2 = geoPositions[branch.to];
                    if (!p1 || !p2) return null;

                    const color = getEdgeColor(branch);
                    const lineData = lineCurrents[branch.id];
                    const percentage = lineData?.percentage || 0;
                    
                    // Mostra tracejado se estiver aberta
                    const isClosed = branch.state === 1;
                    const path = routedPaths[branch.id] || [[p1.lat, p1.lng], [p2.lat, p2.lng]];
                    
                    // Destaque visual temporário se esta linha estiver sendo recalculada
                    const isRecalculating = recalculatingBranchId === branch.id;
                    const lineColor = isRecalculating ? '#e91e63' : color;
                    const lineOpacity = isRecalculating ? 0.5 : (isClosed ? 0.9 : 0.3);

                    return (
                        <Polyline 
                            key={`branch-${branch.id}`}
                            positions={path}
                            color={lineColor}
                            weight={routedPaths[branch.id] ? 4 : 5}
                            opacity={lineOpacity}
                            dashArray={isClosed ? null : "10, 10"}
                            eventHandlers={{
                                click: () => { 
                                    setSelectedElement({ type: 'edge', data: branch }); 
                                    if (isEditMode) {
                                        recalculateSingleRoute(branch.id);
                                    } else if (branch.hasSwitch) {
                                        toggleSwitch(branch.id); 
                                    }
                                }
                            }}
                        >
                            <Tooltip sticky>
                                <div style={{ textAlign: 'center' }}>
                                    <strong>Linha {branch.from}-{branch.to}</strong><br/>
                                    {isClosed ? `Carga: ${percentage.toFixed(1)}%` : 'ABERTA'}
                                </div>
                            </Tooltip>
                        </Polyline>
                    );
                })}

                {Object.keys(geoPositions).map(nodeId => {
                    const numId = parseInt(nodeId);
                    const pos = geoPositions[nodeId];
                    const isSource = sources.includes(numId);
                    const isFeeder = feedersList.includes(numId);
                    const type = isSource ? 'sub' : (isFeeder ? 'feeder' : 'load');
                    
                    const color = getNodeColor(numId);
                    const v_pu = nodeData[nodeId]?.v || 1.0;

                    return (
                        <Marker 
                            key={`node-${nodeId}`}
                            position={[pos.lat, pos.lng]}
                            draggable={isEditMode}
                            icon={createCustomIcon(nodeId, color, type)}
                            eventHandlers={{
                                dragend: (e) => handleNodeDrag(nodeId, e.target.getLatLng()),
                                click: () => { 
                                    setSelectedElement({ type: 'node', id: numId }); 
                                    if (!isEditMode) toggleFault(numId); 
                                }
                            }}
                        >
                            <Tooltip direction="top" offset={[0, -8]}>
                                <div style={{ textAlign: 'center' }}>
                                    <strong style={{ color: color }}>{isSource ? 'SUB' : (isFeeder ? 'ALIM' : 'BARRA')} {nodeId}</strong><br/>
                                    {v_pu.toFixed(3)} pu
                                </div>
                            </Tooltip>
                        </Marker>
                    );
                })}
            </MapContainer>
            
            {/* A LEGENDA */}
            {children}
        </div>
    );
}