// src/utils/geoRouting.js

export async function fetchStreetRoute(startLat, startLng, endLat, endLng) {
    const start = `${startLng},${startLat}`;
    const end = `${endLng},${endLat}`;
    const url = `https://router.project-osrm.org/route/v1/driving/${start};${end}?geometries=geojson&overview=full`;

    // 👇 DEFESA CONTRA LENTIDÃO: Aborta a requisição se demorar mais de 4 segundos
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000);

    try {
        const response = await fetch(url, { signal: controller.signal });
        clearTimeout(timeoutId); // Limpa o timer se respondeu rápido
        
        if (!response.ok) throw new Error("Falha na API OSRM");
        const data = await response.json();
        
        if (data.routes && data.routes.length > 0) {
            const coordinates = data.routes[0].geometry.coordinates;
            return coordinates.map(coord => [coord[1], coord[0]]); // Inverte Lng/Lat para Lat/Lng
        }
        return null;
    } catch (error) {
        clearTimeout(timeoutId);
        console.warn(`⏳ OSRM demorou muito para o trecho. Usando reta para não travar.`);
        return null;
    }
}